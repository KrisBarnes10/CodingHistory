import requests

def create_template(urlBase, headers, root_path_id, template_model):

  url = urlBase + "tfapi/template?rootPathId={0}".format(root_path_id)
  return requests.request("POST", url, headers=headers, data=template_model)


