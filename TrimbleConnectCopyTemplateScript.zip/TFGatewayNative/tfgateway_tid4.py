import requests
import webbrowser
import json
import shelve

from datetime import datetime
from datetime import timezone
import pytz

from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qsl

REDIRECT_URI = "http://localhost:5000/index.html"

# HTTP server to listen to response from single sign on.  First GET request, grab the authorization code and we're done.
class _SsoAuthRequestHandler(BaseHTTPRequestHandler):

  keep_running = True
  authorization_code = ""

  def do_GET(self):
    #print(f"GET request,\nPath: {str(self.path)}\nHeaders:\n{str(self.headers)}\nRequest:\n{str(self.request)}\n")

    path = urlparse(self.path)
    query = parse_qsl(path.query)
    _SsoAuthRequestHandler.authorization_code = next(q[1] for q in query if q[0] == "code")

    _SsoAuthRequestHandler.keep_running = False


def log_in(url_base):

  # Get ssoLoginUri from TFGateway, and open in a browser

  url = url_base + "tfapi/account/login/redirecttossologinuri?redirectFromSSOLoginUri=" + REDIRECT_URI

  sso_login_uri = requests.get(url)
  sso_login_uri_str = sso_login_uri.text.strip('"')
   
  webbrowser.open(sso_login_uri_str, new=1)

  # Create an HTTP server to listen for response from single sign on
  webserver = HTTPServer(("localhost", 5000), _SsoAuthRequestHandler)
  while _SsoAuthRequestHandler.keep_running:
    webserver.handle_request()

  # Use the authorization code to log in via TFGateway

  url = url_base + "tfapi/account/login?authorizationCode={0}&redirectFromSSOLoginUri={1}".format(_SsoAuthRequestHandler.authorization_code,
                                                                                                  REDIRECT_URI)

  response = requests.post(url)

  print(response.text + '\n')

  response_object = json.loads(response.text)
  accessToken = response_object["accesstoken"]
  expiry_utc = response_object["expiryutc"]

  return accessToken, expiry_utc


def log_in_if_required(url_base):
  # Use shelved access token if possible, else log in and shelve the access token and expiry datetime
  shelf = shelve.open('token')

  try:
    access_token = shelf['access_token']
    expiry_utc = shelf['expiry_utc']
  except:
    access_token = ''
    expiry_utc = ''
    expired = True

  if expiry_utc != '':
    expiry_utc_str = expiry_utc[:26] + expiry_utc[27:] # Remove 7th decimal value after seconds = we want microseconds (6 digits)
    expiry_datetime = datetime.strptime(expiry_utc_str, '%Y-%m-%dT%H:%M:%S.%fZ').replace(tzinfo=pytz.UTC)
    expired = datetime.now(timezone.utc) > expiry_datetime

  if access_token == '' or expired:
    access_token, expiry_utc = log_in(url_base)
    shelf['access_token'] = access_token
    shelf['expiry_utc'] = expiry_utc

  shelf.close()

  return access_token
