import requests

def list_paths(urlBase, headers, parent_path_id='', locations=False):

  url = urlBase + 'tfapi/path?parentPathId={0}&locations={1}'.format(parent_path_id, locations)
  return requests.get(url, headers=headers)


def create_path(urlBase, headers, parent_path_id, name, description='', tag_label=''):

  url = urlBase + 'tfapi/path?parentPathId={0}&name={1}&description={2}&tagLabel={3}'.format(parent_path_id, name, description, tag_label)
  return requests.post(url, headers=headers)
