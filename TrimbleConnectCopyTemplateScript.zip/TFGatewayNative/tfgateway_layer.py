import requests


def create_layer(urlBase, headers, project_id, layer_name, template_id, color_hex_rgb):

  params = {'projectId': project_id, 
            'layerName': layer_name, 
            'templateId': template_id, 
            'colorHexRGB': color_hex_rgb}
            
  url = urlBase + 'tfapi/layer'
  return requests.post(url, params=params, headers=headers)
