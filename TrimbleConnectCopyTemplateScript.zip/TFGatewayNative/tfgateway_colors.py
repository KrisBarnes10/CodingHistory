import requests

def get_colors(urlBase, headers):

  url = urlBase + 'tfapi/colors'
  return requests.get(url, headers=headers)

