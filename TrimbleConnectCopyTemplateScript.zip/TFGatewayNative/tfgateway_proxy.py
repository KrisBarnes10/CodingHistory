import requests

# not yet implemented in TFGateway

def delete_path(urlBase, headers, location, path_id):

  url = urlBase + 'tfapi/connectproxy/{0}/folders/{1}'.format(location, path_id)
  return requests.delete(url, headers=headers)

def delete_root_path(urlBase, headers, location, path_id):

  url = urlBase + 'tfapi/connectproxy/{0}/projects/{1}'.format(location, path_id)
  return requests.delete(url, headers=headers)

def delete_project(urlBase, headers, location, root_path_id, project_id):

  url = urlBase + 'tfapi/mapsproxy/{0}/projects/{1}/spatialworkspaces/{2}'.format(location, root_path_id, project_id)
  return requests.delete(url, headers=headers)


# this is implemented in TFGateway
def create_template(urlBase, headers, location, root_path_id, template_model):

  url = urlBase + 'tfapi/connectproxy/{0}/projects/{1}/templates'.format(location, root_path_id)
  return requests.post(url, headers=headers, data=template_model)


def get_styles(urlBase, headers, location, root_path_id):

  url = urlBase + 'tfapi/mapsproxy/{0}/projects/{1}/styles'.format(location, root_path_id)
  return requests.get(url, headers=headers)


def create_style(urlBase, headers, location, root_path_id, style_model):

  url = urlBase + 'tfapi/mapsproxy/{0}/projects/{1}/styles'.format(location, root_path_id)
  return requests.post(url, headers=headers, data=style_model)
