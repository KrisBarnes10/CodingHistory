import requests

def create_project(urlBase, headers, parent_path_id, name, description, tag_label='', coordinate_system_id='',
                   latitude_north='', latitude_south='', longitude_east='', longitude_west=''):
  
  url = urlBase + ('tfapi/project?parentPathId={0}&name={1}&description={2}&tagLabel={3}&coordinateSystemId={4}&'
                                 'latitudeNorth={5}&latitudeSouth={6}&longitudeEast={7}&longitudeWest={8}'
                  ).format(parent_path_id, name, description, tag_label, coordinate_system_id, 
                           latitude_north, latitude_south, longitude_east, longitude_west)

  return requests.post(url, headers=headers)
