#Python script for copying and publishing templates from one Trimble Connect Project to another.
#Built and owned by Karissa Barnes of Frontier Precision
#Updated 8/15/2021
#Frontier Precision is in no event liable to you or any third party for any damages resulting in the use or misuse of this script.

import requests
import json

# Local folder
from TFGatewayNative import tfgateway_tid4

urlBase = 'https://tfgateway.trimblegeospatial.com/'

# Log in to TIDv4
access_token, expiry_utc = tfgateway_tid4.log_in(urlBase)
headers = {'Authorization': 'Bearer ' + access_token}
Cookie=access_token

# This uses the native endpoint to get details of the current user
url = urlBase + 'tfapi/currentUser'
response = requests.get(url, headers=headers)

# This uses the MapsProxy endpoint to get details of the current user
url = urlBase + 'tfapi/mapsproxy/northAmerica/auth/currentuser'
response = requests.get(url, headers=headers)


# This uses the native endpoint to get the current user's Root Paths.
url = urlBase + 'tfapi/path'
response = requests.get(url, headers=headers)

# This uses the MapsProxy endpoint to get the current user's Root Paths.
# Note that a TFGateway Root Path corresponds to a Connect Maps Project
url = urlBase + 'tfapi/mapsproxy/northAmerica/projects'
response = requests.get(url, headers=headers)

#Get list of workspaces
url = "https://tfgateway.trimblegeospatial.com/tfapi/project"

payload = {}
headers = {'Authorization': 'Bearer ' + access_token}

response = requests.request("GET", url, headers=headers, data = payload)
print("Trimble Connect Workspaces")
x=response.json()
for item in x:
   print("Name: " + item["name"]+ "\n" "ID: " + item["id"]+"\n")

#Get from workspace ID
print("Copy the ID for the map workspace you want to copy the template from and paste below")
fromWorkspaceID=input()

#Get to workspace ID
print("Copy the ID for the map workspace you want to copy the template to and paste below")
toWorkspaceID=input()

#Get to Connect Project ID
print("Copy the ID for the Project you want to copy the template to and paste below")
print("This will be the first two sections of the last ID. Example: northAmerica|QFgh0BJbe3A")
toProjectID=input()

#List templates for project
url="https://tfgateway.trimblegeospatial.com/tfapi/template?projectId="+fromWorkspaceID+"&includeFullTemplateDetails=true&getLastPublishedTemplate=true"

response = requests.request("GET", url, headers=headers, data = payload)

y=response.json()
for item in y:
    print("Name: " + item["name"]+ "\n" "ID: " + item["id"]+"\n")

#Get from template ID
print("Copy the ID for the template you want to create in the new workspace and paste below")
fromTemplateID=input()

#Get from template details
url = "https://tfgateway.trimblegeospatial.com/tfapi/template/"+fromTemplateID+"?includeFullTemplateDetails=true"

response = requests.request("GET", url, headers=headers, data = payload)
y=response.json()

#Extract the template model for the template payload
templateModel=y["templatemodel"]
templateModelFormat=json.dumps(templateModel, indent=10)

#Get new layer name
print("Enter name for new template")
toLayerName=input()

#Create Template
url = "https://tfgateway.trimblegeospatial.com/tfapi/template?rootPathId="+toProjectID

payload=templateModelFormat
headers = {
  'Content-Type': 'application/json', 'Authorization': 'Bearer ' + access_token
}

response = requests.request("POST", url, headers=headers, data = payload)

y=response.json()
toTemplateID=y["id"]
print("Copying template")

#Create New Layer
url = "https://tfgateway.trimblegeospatial.com/tfapi/layer?projectId="+toWorkspaceID+"&layerName="+toLayerName+"&templateId="+toTemplateID+"&colorHexRGB=%23ff2722"

payload = {}
response = requests.request("POST", url, headers=headers, data = payload)

print("Creating new layer in workspace")

#Publish Template
url = "https://tfgateway.trimblegeospatial.com/tfapi/template/"+toTemplateID+"/publish"

response = requests.request("PUT", url, headers=headers, data = payload)

print("New layer published")

print("Would you like to copy more templates from/to the same workspaces?")
print("Enter Y/N")
moreTemplates=input()

#Loop for copying additional templates
noMoreTemplates='N'
while moreTemplates != noMoreTemplates:
    #List templates for project
    url="https://tfgateway.trimblegeospatial.com/tfapi/template?projectId="+fromWorkspaceID+"&includeFullTemplateDetails=true&getLastPublishedTemplate=true"

    response = requests.request("GET", url, headers=headers, data = payload)

    y=response.json()
    for item in y:
        print("Name: " + item["name"]+ "\n" "ID: " + item["id"]+"\n")
    
    #Get from template ID
    print("Copy the ID for the template you want to create in the new workspace and paste below")
    fromTemplateID=input()
    
    #Get from template details
    url = "https://tfgateway.trimblegeospatial.com/tfapi/template/"+fromTemplateID+"?includeFullTemplateDetails=true"

    response = requests.request("GET", url, headers=headers, data = payload)
    y=response.json()

    #Extract the template model for the template payload
    templateModel=y["templatemodel"]
    templateModelFormat=json.dumps(templateModel, indent=10)

    #Get new layer name
    print("Enter name for new template")
    toLayerName=input()

    #Create Template
    url = "https://tfgateway.trimblegeospatial.com/tfapi/template?rootPathId="+toProjectID

    payload=templateModelFormat
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer ' + access_token}

    response = requests.request("POST", url, headers=headers, data = payload)

    y=response.json()
    toTemplateID=y["id"]
    print("Copying template")

    #Create New Layer
    url = "https://tfgateway.trimblegeospatial.com/tfapi/layer?projectId="+toWorkspaceID+"&layerName="+toLayerName+"&templateId="+toTemplateID+"&colorHexRGB=%23ff2722"

    payload = {}
    response = requests.request("POST", url, headers=headers, data = payload)

    print("Creating new layer in workspace")

    #Publish Template
    url = "https://tfgateway.trimblegeospatial.com/tfapi/template/"+toTemplateID+"/publish"

    response = requests.request("PUT", url, headers=headers, data = payload)

    print("New layer published")
        
    print("Would you like to copy more templates from/to the same workspaces?")
    print("Enter Y/N")
    moreTemplates=input()